﻿using System.Windows.Controls;

namespace MaterialDesignDemo.TransitionsDemo
{
    /// <summary>
    /// Interaction logic for Slide2_Intro.xaml
    /// </summary>
    public partial class Slide2_Intro : UserControl
    {
        public Slide2_Intro()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Controls;

namespace MaterialDesignDemo.TransitionsDemo
{
    /// <summary>
    /// Interaction logic for Slide1_Intro.xaml
    /// </summary>
    public partial class Slide1_Intro : UserControl
    {
        public Slide1_Intro()
        {
            InitializeComponent();
        }
    }
}

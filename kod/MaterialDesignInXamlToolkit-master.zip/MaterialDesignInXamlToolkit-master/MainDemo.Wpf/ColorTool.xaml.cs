﻿namespace MaterialDesignDemo
{
    /// <summary>
    /// Interaction logic for ColorTool.xaml
    /// </summary>
    public partial class ColorTool
    {
        public ColorTool()
        {
            InitializeComponent();
        }
    }
}

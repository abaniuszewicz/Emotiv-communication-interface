﻿using System.Windows.Controls;

namespace MaterialDesignDemo
{
    /// <summary>
    /// Interaction logic for Drawers.xaml
    /// </summary>
    public partial class Drawers : UserControl
    {
        public Drawers()
        {
            InitializeComponent();
        }
    }
}
